export interface User{
    firstName :string,
    middleName :string,
    lastName :string,
    flat :string,
    mobile :string,
    password :string,
    email :string
}

export interface LoginUser{
    email :string,
    password :string
}
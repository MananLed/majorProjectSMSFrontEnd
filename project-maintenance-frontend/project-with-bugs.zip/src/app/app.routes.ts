import { Routes } from '@angular/router';
import { ServiceRequestsComponent } from './dashboard/views/service-requests/service-requests.component';
import { DashboardComponent } from './dashboard/dashboard.component';

export const routes: Routes = [
  {
    path: 'dashboard',
    // loadComponent: () =>
    //   import('./dashboard/dashboard.component').then(c => c.DashboardComponent),
    component: DashboardComponent,
    children: [
      {
        path: 'request',
        loadComponent: () =>
          import('./dashboard/views/service-requests/service-requests.component')
            .then(c => c.ServiceRequestsComponent)
      },
      {
        path: 'user-management',
        loadComponent: () =>
          import('./dashboard/views/user-management/user-management.component')
            .then(c => c.UserManagementComponent)
      },
    //   { path: '', redirectTo: 'overview', pathMatch: 'full' }
    ]
  },
//   { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];
import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-7JJXV6KY.js";
import "./chunk-JHZG4NAZ.js";
import "./chunk-G5XDY66V.js";
import "./chunk-MSTHHLWK.js";
import "./chunk-HJEFZBOK.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
